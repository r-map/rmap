R-map: participative environmental monitoring net.
