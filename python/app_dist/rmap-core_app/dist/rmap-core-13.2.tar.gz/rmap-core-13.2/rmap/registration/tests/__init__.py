from registration import admin
from registration.backends.default import urls


def test():
    assert admin
    assert urls
