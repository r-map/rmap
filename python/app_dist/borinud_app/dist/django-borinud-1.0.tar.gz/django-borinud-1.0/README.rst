Django web services to provide weather data.
Part of RMAP project: participative environmental monitoring net.
